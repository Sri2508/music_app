import React from 'react'
import './MusicController.css';

export default function MusicController(){
    return(
        <div className='main-container'>
            <div class="music-control-bar">
                <div class="song-info">
                    <img src="https://daily.jstor.org/wp-content/uploads/2023/01/good_times_with_bad_music_1050x700.jpg" />
                    <div className='song-info-text'>
                        <h4 class="card-title">Song Title</h4>
                        <p class="card-text">Artist</p>
                    </div>
                    <i class="fa-regular fa-heart" style={{color: '#ffffff', marginLeft:'20px'}}></i>
                </div>
                <div className='audio-controls'>    
                <div class="playback-controls">
                    <button class="fa-solid fa-backward-step" style={{color: '#ffffff'}}></button>
                    <button class="fa fa-play" style={{color: '#ffffff'}}></button>
                    <button class="fa-solid fa-forward-step" style={{color: '#ffffff'}}></button>
                </div>
                <div class="progress-bar">
                    <div class="progress-bar-inner"></div>
                </div>
                </div>
                <div className='volume-control' >
                    <div>
                        <button class="fa-solid fa-volume-high" style={{color:'#ffffff'}}></button>
                    </div>
                    <div class="volume-bar">
                        <div class="volume-bar-inner"></div>
                    </div>
                </div>
            </div>

        </div>
    )
}