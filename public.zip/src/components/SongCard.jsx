import React,{useState, useEffect} from 'react'
import '../pages/home.css'
import './SongCard.css';
import axios from 'axios';


export function ListSongCard({song_id, albumname, artistname, image }){let userData = sessionStorage.getItem('userData');
const parsedUserData = JSON.parse(userData);
const user_id = parsedUserData[0]._id;
const [songData, setSongData] = useState([]);
const [likedSongIds, setLikedSongIds] = useState([]);
console.log("This is the user id: " + user_id);

useEffect(() => {
  // Step 1: Fetch liked song IDs
  axios.get(`http://127.0.0.1:5000/user/${user_id}/favorites/`)
    .then((response) => {
      setLikedSongIds(response.data);
    })
    .catch((error) => {
      console.error('Error fetching liked song IDs: ', error);
    });
}, [user_id]);

useEffect(() => {
  // Step 2: Fetch detailed song data for each liked song
  const fetchSongData = async () => {
    const songDataPromises = likedSongIds.map((songId) =>
      axios.get(`http://127.0.0.1:5000/songs/${songId}`)
    );

    try {
      const responses = await Promise.all(songDataPromises);
      const songs = responses.map((response) => response.data);
      setSongData(songs);
    } catch (error) {
      console.error('Error fetching song data: ', error);
    }
  };

  fetchSongData();
}, [likedSongIds]);
console.log(songData)
  return(
    <>
    <div class="tbl-header">
    <table cellpadding="0" cellspacing="0" border="0">
      <thead>
        <tr>
          <th>#</th>
          <th>Title</th>
          <th>Artist</th>
          <th>Duration</th>
          <th><i class="fa-regular fa-heart" style={{color: "#ffffff"}}></i></th>
        </tr>
      </thead>
    </table>
  </div>
  <div class="tbl-content">
    <table cellpadding="0" cellspacing="0" border="0">
      <tbody>
         {songData.map((song, index) => (
            <tr key={song._id}>
              <td>{index + 1}</td>
              <td><img src={song.image} alt={song.albumname} style={{width:'35px', height:'35px', paddingRight:'3px'}}/>{song.albumname}</td>
              <td>{song.artistname}</td>
              <td>1.56</td>
              <td>LikeBtn</td>
            </tr>
          ))}
      </tbody>
    </table>
  </div>
  </>
  );
}

export default function SongCard({user_id, id, albumname, artistname, image }){
  async function handleLikeClick({user_id, id}) {
    console.log(id)
    console.log(user_id)
    try {
      const response = await axios.post(`http://127.0.0.1:5000/user/${user_id}/favorites/${id}`);
      console.log(response.data); // Handle the response from the server

      if(response.status===200){
        
      }


    } catch (error) {
      console.error(error); // Handle any errors that occur
    }
  };

  
  return (
    <div>
        <div class="item">
          <img src={image} style={{height:'87px', width:'130'}}/>
            <div class="play" style={{right:'-7px',}}>
                <button class="fa fa-play" style={{border:'none'}}></button>
            </div>
            <h4 class="card-title">{albumname}</h4>
            <p class="card-text">{artistname}</p>
            <div className='likeaddbutton'>
              <div class="play" >
                  <button onClick={() => handleLikeClick({user_id, id})} class="fa fa-heart fa-xs" style={{border:'none',backgroundColor:'grey',color:'#000000', padding: '14px'}}></button>
              </div>
              <div class="play" style={{right:'0px', top:'50px'}}>
                <button class="fa fa-plus fa-xs" style={{border:'none',backgroundColor:'grey',color:'#000000', padding: '14px'}}></button>
              </div>
            </div>
        </div>
    </div>

    
  )
}
