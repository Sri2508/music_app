import React from 'react'
import '../pages/home.css'
import SearchBar from './Searchbar';

export default function Topbar(){
  const goBack = () => {
    window.history.back(); 
  };

  const goForward = () => {
    window.history.forward();
  };
    return(
        <div class="topbar">
          <div class="prev-next-buttons">
            <button type="button" class="fa fas fa-chevron-left" onClick={goBack}></button>
            <button type="button" class="fa fas fa-chevron-right" onClick={goForward}></button>
          </div>
          <div id="searchContainer" style={{paddingLeft:'15rem', paddingTop:'0.3rem', position:'fixed'}}>
            <SearchBar/>
          </div>
          <div class="prev-next-buttons">
            <div class="dropdown">
              <button type="button" class="fa fas fa-solid fa-bell" style={{backgroundColor:'#121212'}}></button>
                <div class="dropdown-content" >
                  <a href="#">notification 1</a>
                  <a href="#">notification 2</a>
                  <a href="#">notification 3</a>
                </div>
            </div>  
            
            <div class="dropdown">
              <button type="button" class='profile-pic' style={{backgroundColor:'#121212'}}><img src='https://cdn-icons-png.flaticon.com/512/3135/3135715.png' style={{borderRadius:'10px', width:'30px', height:'30px'}}></img></button>
                <div class="dropdown-content" >
                  <a href="#">Profile</a>
                  <a href="/">Logout</a>
                </div>
            </div> 
          </div>
          
        </div>
    );
}