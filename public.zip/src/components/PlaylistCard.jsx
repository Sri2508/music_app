import React from 'react'
import '../pages/home.css'
import SongCard, { ListSongCard } from '../components/SongCard'
import '../pages/LikedSongs.css'


export function PlaylistSongs(){
  return(<div className='main-container-content'>
          <div class="songslist">
            <div className='cover'>
              <img className='likeimg'src="https://mir-s3-cdn-cf.behance.net/project_modules/hd/00f56557183915.59cbcc586d5b8.jpg" style={{width:'200px', height:'200px'}}></img>
              <div className='text'>
                <h1>Playlist</h1>
                <p>user. count songs</p>
              </div>
            </div>
            <div class="list">
              <div className='likepageplay'></div>
                <button class="fa fa-play" style={{border:'none',backgroundColor:'#1fdf64', height:'60px',width:'60px', borderRadius:'30px'}}></button>
              <ListSongCard/>
            </div>
          </div>
        </div>);
}

export default function PlaylistCard({ setActiveComponent }){
  return (
    <div>
        <div class="item" onClick={() => setActiveComponent('playlistsongs')}>
          <img src="https://daily.jstor.org/wp-content/uploads/2023/01/good_times_with_bad_music_1050x700.jpg" />
            <div class="play" style={{right:'-7px',}}>
                <button class="fa fa-play" style={{border:'none'}}></button>
            </div>
            <h4 class="card-title">PlaylistCard title</h4>
            <p class="card-text">Artist names</p>
            <div className='likeaddbutton'>
              <div class="play" >
                  <button class="fa fa-heart fa-xs" style={{border:'none',backgroundColor:'grey',color:'#000000', padding: '14px'}}></button>
              </div>
            </div>
        </div>
    </div>

    
  )
}
