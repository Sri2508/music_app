
import '../pages/home.css';

export default function SideNavbar({ setActiveComponent }){
    return(
        <div class="sidebar">
        <div class="logo" style={{paddingLeft:'30px', color:'white'}}>
          <a href="#">
            <img src="https://krosbits.in/images/musicolet_round.png" alt="Logo" />
          </a>
          <h4 style={{paddingLeft:'20px'}}>Musix</h4>
        </div>

        <div class="navigation">
          <ul>
            <li>
              <button style={{backgroundColor:'black'}} onClick={() => setActiveComponent('home')}>
                <span class="fa fa-home" style={{color:'white'}}></span>
                <a>Home</a>
              </button>
            </li>
            <li>
            <button style={{backgroundColor:'black'}}onClick={() => setActiveComponent('yourlibrary')}>
                <span class="fa fas fa-book" style={{color:'white'}}></span>
                <a >Your Library</a>
              </button>
            </li>
          </ul>
        </div>

        <div class="navigation">
          <ul>
            <li>
            <button style={{backgroundColor:'black'}}onClick={() => setActiveComponent('createplaylist')}>
                <span class="fa fas fa-plus-square" style={{color:'white'}}></span>
                <a href=''>Create Playlist</a>
              </button>
            </li>

            <li>
              <button style={{backgroundColor:'black'}} onClick={() => setActiveComponent('likes')}>
                <span class="fa fas fa-heart" style={{color:'white'}}></span>
                <a>Liked Songs</a>
              </button>
            </li>
          </ul>
        </div>
      </div>
    );
}