import './Searchbar.scss'; 

export default function SearchBar(){
    return (
      <>
	  <div class="container">
			<div class="search-box">
				<input type="text" />
				<span></span>
			</div>
		</div>
	  </>
    );
  };
  