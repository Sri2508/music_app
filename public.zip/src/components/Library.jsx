import React,{useState} from 'react'
import '../pages/home.css'
import PlaylistCard,{PlaylistSongs} from '../components/PlaylistCard'; 



export default function Library(){
  const [activeComponent, setActiveComponent] = useState('playlist');
  return(<div className='main-container-content'>
          <div class="playlists">
            <div className='list'>
              {activeComponent === 'playlist' && <PlaylistCard setActiveComponent={setActiveComponent}/>}
              {activeComponent === 'playlistsongs' && <PlaylistSongs />}
            </div> 
          </div>
        </div>);
}


