import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import PageNotFound from './pages/PageNotfound.js'; // Renamed PageNotfound to PageNotFound
import Registration from './pages/Authentication/Registration'; // Changed Authetication to Authentication
import Login from './pages/Authentication/Login'; // Changed Authetication to Authentication

function App() {
  return (
    <Router className="App">
      <Routes>
        <Route path="/" element={<Registration />} />
        <Route path="/home" element={<Home />} />
        <Route path="/login" element={<Login />} /> {/* Changed to /login */}
        <Route path="*" element={<PageNotFound />} /> {/* Changed to PageNotFound */}
      </Routes>
    </Router>
  );
}

export default App;
