import React,{useState, useEffect} from 'react'
import './home.css'
import SideNavbar from '../components/SideNavbar';
import PlaylistCard, { PlaylistSongs } from '../components/PlaylistCard'; 
import SongCard from '../components/SongCard';
import MusicController from '../components/MusicController';
import Topbar from '../components/Topbar';
import LikedSongs from './LikedSongs';
import Library from '../components/Library';
import axios from 'axios';



export function Home_content(){
  let userData = sessionStorage.getItem('userData');
  const parsedUserData = JSON.parse(userData);
  const userid = parsedUserData[0]._id;
   

  const [activeComponent, setActiveComponent] = useState('playlist');
  const [songData, setSongData] = useState([]);

  useEffect(() => {
    // Make an Axios GET request to your API endpoint
    axios.get('http://127.0.0.1:5000/songs')
      .then((response) => {
        setSongData(response.data);
      })
      .catch((error) => {
        console.error('Error fetching song data: ', error);
      });
  }, []);

  console.log(songData)
  

  return(
          <div className='main-container-content'>
            <div class="playlists">
              <h2>Playlists</h2>

              <div className='list'>
                {activeComponent === 'playlist' && <PlaylistCard setActiveComponent={setActiveComponent}/>}
                {activeComponent === 'playlistsongs' && <PlaylistSongs />}
              </div>
          </div>

          <div class="playlists">
            <h2>Songs</h2>
            <div class="list">
            {songData.map((song, index) => (
            <SongCard
              key={index}
              user_id = {userid}
              id={song._id}
              albumname={song.albumname}
              artistname={song.artistname}
              image={song.image}
            />
          ))}
            </div>
          </div>
        </div>);
}



export default function Home(){
  const [activeComponent, setActiveComponent] = useState('home');
  return (
    <>
      <SideNavbar setActiveComponent={setActiveComponent}/>
      <div class="main-container">
        <Topbar/>
        {activeComponent === 'home' && <Home_content />}
        {activeComponent === 'likes' && <LikedSongs  />}
        {activeComponent === 'yourlibrary' && <Library/>}
        {activeComponent === 'createplaylist' && <createplaylist />}
      </div>
      <MusicController/>
    </>
  )
}


