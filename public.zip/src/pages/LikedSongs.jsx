import React,{useState, useEffect} from 'react'
import SongCard, { ListSongCard } from '../components/SongCard'

import './LikedSongs.css'





export default function LikedSongs(){
  return(<div className='main-container-content'>
          <div class="songslist">
            <div className='cover'>
              <img className='likeimg'src="https://i.scdn.co/image/ab67706c0000da8470d229cb865e8d81cdce0889" style={{width:'200px', height:'200px'}}></img>
              <div className='text'>
                <p>Playlist</p>
                <h1>Liked Songs</h1>
                <p>user. count songs</p>
              </div>
            </div>
            <div class="list">
              <div className='likepageplay'></div>
                <button class="fa fa-play" style={{border:'none',backgroundColor:'#1fdf64', height:'60px',width:'60px', borderRadius:'30px'}}></button>
            <ListSongCard/>
            </div>
          </div>
        </div>);
}