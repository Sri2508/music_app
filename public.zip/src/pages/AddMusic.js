import React from 'react'

const AddMusic = () => {
  return (
    <div className='container'>
      <h1>Add a Song</h1>
        <form>
            <div class="row mb-3">
                <label for="inputEmail3" class="col-sm-2 col-form-label">Song Name</label>
                <div class="col-sm-10">
                <input type="email" class="form-control" id="inputEmail3" />
                </div>
            </div>
            <div class="row mb-3">
                <label for="inputPassword3" class="col-sm-2 col-form-label">Song Image</label>
                <input type="file" id="myFile" name="filename" />
            </div>
            <div class="row mb-3">
                <label for="inputPassword3" class="col-sm-2 col-form-label">Song Upload</label>
                <input type="file" id="myFile" name="filename" />
            </div>
            <button type="submit" class="btn btn-primary">Upload Song</button>
        </form>
    </div>
  )
}

export default AddMusic