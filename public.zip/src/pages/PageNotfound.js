import React from 'react';
import { Link } from 'react-router-dom';

const containerStyle = {
  textAlign: 'center',
};

const logoStyle = {
  width: '150px',
  height: '150px',
  borderRadius: '50%',
  display: 'block',
  margin: '0 auto',
  marginTop: '80px',
};

const headerStyles = {
  color: 'white',
  fontWeight: 'bold',
  marginTop: '30px',
};

const paragraphStyles = {
  color: 'white',
  marginTop: '40px',
};

const buttonStyles = {
  display: 'block',
  margin: '50px auto',
};

const homeButtonStyles = {
  backgroundColor: 'white',
  color: 'black',
  fontWeight:'bold',
  borderRadius: '30%',
  padding: '10px 20px',
};

const PageNotfound = () => {
  return (
    <div style={containerStyle}>
      <img
        src="https://www.electronicshub.org/wp-content/uploads/2023/02/new-spotify-logo.png"
        alt="Spotify Logo"
        style={logoStyle}
      />
      <h1 style={headerStyles}>Page Not Found</h1>
      <p style={paragraphStyles}>We can't seem to find the page you are looking for!</p>
      <div style={buttonStyles}>
        <Link to="/Login">
          <button style={homeButtonStyles}>Home</button>
        </Link>
      </div>
    </div>
  );
};

export default PageNotfound;