import React, { useState } from 'react';
import './Login.css'; // Import your custom CSS for styling
import axios from 'axios';
import {  useNavigate } from 'react-router-dom';

const Login = () => {
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    email:'',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const response = await axios.post('http://127.0.0.1:5000/login', formData);
      console.log(response.data); // Handle the response from the server

      if(response.status===200){
        navigate('/home')
      }

      axios.get('http://127.0.0.1:5000/login/'+formData.email)
      .then((response) => {
        sessionStorage.setItem('userData', JSON.stringify(response.data));
      })
      .catch((error) => {
        console.error('Error fetching song data: ', error);
      });

    } catch (error) {
      console.error(error); // Handle any errors that occur
    }
  };
  return (
    <div className="login-container">
      <div className="login-wrapper">
        <form onSubmit={handleSubmit} className="login-form">
          <div className="form-group">
            <p className="login-text" style={{color:'white'}}>Login to your account</p>
          </div>
          <div className="form-group">
            <input
              type="text"
              name="username"
              placeholder="Username"
              value={formData.username}
              onChange={handleInputChange}
            />
          </div>
          <div className="form-group">
            <input
              type="password"
              name="password"
              placeholder="Password"
              value={formData.password}
              onChange={handleInputChange}
            />
          </div>
          <div className="form-group">
            <input
              type="email"
              name="email"
              placeholder="Email"
              value={formData.email}
              onChange={handleInputChange}
            />
          </div>
          <button type="submit" className="login-button">
            Log In
          </button>
          <p style={{paddingTop:'5px', color:'white'}}>New user? <a href='/' style={{textDecoration: "none"}}><b style={{color:'#1DB954'}}>Register</b></a></p>
        </form>
      </div>
    </div>
  );
};

export default Login;
